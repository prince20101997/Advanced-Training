package com.java.advance;
import java.util.*;
public class RectangleArea {

	int length;
	int breadth;
	int area;
	
	public RectangleArea()
	{
		length=0;
		breadth=0;
	}
	void input() {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the length of rectangle: ");
		length=sc.nextInt();
		System.out.println("Enter the breadth of rectangle: ");
		breadth=sc.nextInt();
	}
	void calculate() {
		area=length*breadth;
	}
	void display() {
		System.out.println("Area of Rectangle = "+area);
	}
	
	public static void main(String args[]) {
		RectangleArea obj1=new RectangleArea();
		obj1.input();
		obj1.calculate();
		obj1.display();
	}
}
