package com.java.advanced;

public abstract class Instrument {
	public abstract void play();

}
